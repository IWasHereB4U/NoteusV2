import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext.jsx';
import { YardProvider } from './context/YardContext.jsx';
import { AccentSync } from './context/ShadeContext.jsx';
import { ProtectedRoute } from './components/ProtectedRoute.jsx';
import { Layout } from './components/Layout.jsx';
import { Login } from './pages/Login.jsx';
import { Dashboard } from './pages/Dashboard.jsx';
import { Clients } from './pages/Clients.jsx';
import { Money } from './pages/Money.jsx';
import { Calorie } from './pages/Calorie.jsx';
import { Bankbook } from './pages/Bankbook.jsx';
// MGOctaviano07Oct2026: Invoices page removed; Project Timeline added.
import { ProjectTimeline } from './pages/ProjectTimeline.jsx';
import { Tasks } from './pages/Tasks.jsx';
import { Meetings } from './pages/Meetings.jsx';
import { Timesheet } from './pages/Timesheet.jsx';
import { Calendar } from './pages/Calendar.jsx';
import { FilingDesk } from './pages/FilingDesk.jsx';
import { Settings } from './pages/Settings.jsx';
import { Circle } from './pages/Circle.jsx';
import { Notes } from './pages/Notes.jsx';
import { NoteTags } from './pages/NoteTags.jsx';
import { Destination } from './pages/Destination.jsx';
import { Poi } from './pages/Poi.jsx';
import { Converter } from './pages/Converter.jsx';
import { Documentasheion } from './pages/Documentasheion.jsx';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AccentSync />
        <YardProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }
          >
            <Route path="/" element={<Dashboard />} />
            <Route path="/clients" element={<Clients />} />
            <Route path="/money" element={<Money />} />
            <Route path="/bankbook" element={<Bankbook />} />
            <Route path="/calorie" element={<Calorie />} />
            {/* MGOctaviano07Oct2026: /invoices route removed */}
            <Route path="/project-timeline" element={<ProjectTimeline />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/meetings" element={<Meetings />} />
            <Route path="/timesheet" element={<Timesheet />} />
            <Route path="/calendar" element={<Calendar />} />
            <Route path="/filing" element={<FilingDesk />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/circle" element={<Circle />} />
            <Route path="/notes" element={<Notes />} />
            <Route path="/note-tags" element={<NoteTags />} />
            <Route path="/destination" element={<Destination />} />
            {/* Maps was renamed Destination; keep old bookmarks working. */}
            <Route path="/maps" element={<Navigate to="/destination" replace />} />
            <Route path="/poi" element={<Poi />} />
            <Route path="/converter" element={<Converter />} />
            <Route path="/documentasheion" element={<Documentasheion />} />
          </Route>
        </Routes>
        </YardProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
